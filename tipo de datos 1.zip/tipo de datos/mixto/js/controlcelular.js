// Archivo: ControlCelular.js

class ControlCelular {

  // --- 🔹 5 PÚBLICOS ---
  marca;              // Marca del celular
  modelo;             // Modelo del dispositivo
  sistemaOperativo;   // Android / iOS
  almacenamiento;     // Capacidad en GB
  encendido;          // Estado del celular

  // --- 🔹 5 PRIVADOS ---
  #nivelBateria;      // Nivel actual de batería
  #conectadoWifi;     // Si está o no conectado a Wi-Fi
  #codigoDesbloqueo;  // Código PIN o huella
  #registroBinario;   // Simulación de datos binarios (logs del sistema)
  #configuracionJSON; // Configuraciones avanzadas en JSON

  // --- 🔹 5 PROTEGIDOS (simulados con "_") ---
  _versionSoftware;   // Versión del sistema operativo
  _fechaUltimaCarga;  // Fecha/hora de la última carga
  _modoOscuro;        // Si el modo oscuro está activado
  _temperatura;       // Temperatura del dispositivo
  _listaAplicaciones; // Lista de apps instaladas

  // --- 🔹 Constructor ---
  constructor(marca, modelo, sistemaOperativo, almacenamiento, encendido) {
    this.marca = marca;
    this.modelo = modelo;
    this.sistemaOperativo = sistemaOperativo;
    this.almacenamiento = almacenamiento;
    this.encendido = encendido;

    // Inicialización de valores privados y protegidos
    this.#nivelBateria = 100;
    this.#conectadoWifi = false;
    this.#codigoDesbloqueo = "0000";
    this._versionSoftware = "1.0.0";
    this._modoOscuro = false;
    this._listaAplicaciones = ["Teléfono", "Mensajes", "Cámara", "Galería"];
  }

  // --- 🔹 Getters y Setters ---
  get nivelBateria() {
    return this.#nivelBateria;
  }

  set nivelBateria(nivel) {
    if (nivel >= 0 && nivel <= 100) {
      this.#nivelBateria = nivel;
    } else {
      console.warn(" Nivel de batería no válido");
    }
  }

  get configuracionJSON() {
    return this.#configuracionJSON;
  }

  set configuracionJSON(config) {
    this.#configuracionJSON = config;
  }

  // --- 🔹 Métodos de acción ---
  encenderCelular() {
    if (!this.encendido) {
      this.encendido = true;
      console.log(`📱 El celular ${this.marca} ${this.modelo} ha sido encendido.`);
    } else {
      console.log("El celular ya está encendido.");
    }
  }

  apagarCelular() {
    if (this.encendido) {
      this.encendido = false;
      console.log(" El celular se ha apagado correctamente.");
    } else {
      console.log(" El celular ya está apagado.");
    }
  }

  cargarBateria() {
    this._fechaUltimaCarga = new Date();
    this.#nivelBateria = 100;
    console.log(`Batería cargada al 100%. Última carga: ${this._fechaUltimaCarga.toLocaleString()}`);
  }

  conectarWifi(red) {
    this.#conectadoWifi = true;
    console.log(`Conectado a la red Wi-Fi "${red}" correctamente.`);
  }

  abrirAplicacion(app) {
    if (!this.encendido) {
      console.log("No puedes abrir aplicaciones con el celular apagado.");
      return;
    }

    if (this._listaAplicaciones.includes(app)) {
      console.log(` Abriendo la aplicación: ${app}...`);
      this.#nivelBateria -= 3; // consumo simulado
    } else {
      console.log(` La aplicación "${app}" no está instalada.`);
    }
  }

  // --- 🔹 Mostrar información general ---
  mostrarEstado() {
    console.log("----- Estado del Celular -----");
    console.log(`Marca: ${this.marca}`);
    console.log(`Modelo: ${this.modelo}`);
    console.log(`SO: ${this.sistemaOperativo}`);
    console.log(`Versión: ${this._versionSoftware}`);
    console.log(`Encendido: ${this.encendido}`);
    console.log(`Batería: ${this.#nivelBateria}%`);
    console.log(`Modo oscuro: ${this._modoOscuro ? "Activado" : "Desactivado"}`);
    console.log(`Aplicaciones instaladas: ${this._listaAplicaciones.join(", ")}`);
  }
}

// --- 🔹 Ejemplo de uso ---
const miCelular = new ControlCelular("Samsung", "Galaxy S24", "Android", 256, false);

// Configuración JSON
miCelular.configuracionJSON = {
  idioma: "Español",
  region: "Latinoamérica",
  brillo: 70,
  sonido: true
};

// Acciones simuladas
miCelular.encenderCelular();
miCelular.conectarWifi("RedCasa_5G");
miCelular.abrirAplicacion("Cámara");
miCelular.mostrarEstado();
miCelular.cargarBateria();
miCelular.apagarCelular();
