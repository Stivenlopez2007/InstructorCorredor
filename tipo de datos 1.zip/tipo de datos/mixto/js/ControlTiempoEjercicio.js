// Archivo: ControlTiempoEjercicio.js

class ControlTiempoEjercicio {


  nombreUsuario;         // Nombre del deportista
  tipoEjercicio;         // "Correr", "Natación", "Yoga"
  duracionMinutos;       // Duración planificada
  caloriasQuemadas;      // Calorías estimadas
  sesionActiva;          // Si la sesión está en curso o no

  #frecuenciaCardiaca;   // Frecuencia cardíaca actual
  #nivelHidratacion;     // Nivel de hidratación %
  #registroBinario;      // Registro binario de ritmo (simulación)
  #detallesJSON;         // Datos adicionales en JSON (objeto)
  #autenticado;          // Si el usuario inició sesión correctamente


  _fechaInicio;          // Fecha y hora del inicio
  _objetivoMinutos;      // Meta de duración
  _intensidad;           // "Baja", "Media", "Alta"
  _descansoRecomendado;  // Tiempo de descanso sugerido
  _comentarios;          // Observaciones del entrenador

  // --- 🔹 Constructor ---
  constructor(nombreUsuario, tipoEjercicio, duracionMinutos, caloriasQuemadas, sesionActiva) {
    this.nombreUsuario = nombreUsuario;
    this.tipoEjercicio = tipoEjercicio;
    this.duracionMinutos = duracionMinutos;
    this.caloriasQuemadas = caloriasQuemadas;
    this.sesionActiva = sesionActiva;

    // Valores por defecto
    this.#frecuenciaCardiaca = 0;
    this.#nivelHidratacion = 100;
    this._intensidad = "Media";
    this._descansoRecomendado = 10;
    this._comentarios = "";
  }

  // --- 🔹 Getters y Setters privados ---
  get frecuenciaCardiaca() {
    return this.#frecuenciaCardiaca;
  }

  set frecuenciaCardiaca(valor) {
    if (valor > 0 && valor < 220) {
      this.#frecuenciaCardiaca = valor;
    } else {
      console.warn("Frecuencia cardíaca no válida");
    }
  }

  get detallesJSON() {
    return this.#detallesJSON;
  }

  set detallesJSON(obj) {
    this.#detallesJSON = obj;
  }

  // --- 🔹 Métodos de acción ---
  iniciarSesion() {
    this.#autenticado = true;
    this._fechaInicio = new Date();
    this.sesionActiva = true;
    console.log(` Sesión iniciada por ${this.nombreUsuario} el ${this._fechaInicio.toLocaleString()}`);
  }

  registrarRitmo(frecuencia, hidratacion) {
    this.frecuenciaCardiaca = frecuencia;
    this.#nivelHidratacion = hidratacion;
    console.log(` Ritmo cardíaco: ${frecuencia} bpm | 💧 Hidratación: ${hidratacion}%`);
  }

  finalizarSesion() {
    if (!this.sesionActiva) {
      console.log(" No hay sesión activa para finalizar.");
      return;
    }
    this.sesionActiva = false;
    const tiempoReal = Math.floor(Math.random() * this.duracionMinutos);
    console.log(`Sesión finalizada. Duración real: ${tiempoReal} min. Calorías: ${this.caloriasQuemadas}`);
  }

  mostrarResumen() {
    console.log(" Resumen de la sesión ");
    console.log(`Usuario: ${this.nombreUsuario}`);
    console.log(`Ejercicio: ${this.tipoEjercicio}`);
    console.log(`Duración planificada: ${this.duracionMinutos} minutos`);
    console.log(`Calorías estimadas: ${this.caloriasQuemadas}`);
    console.log(`Frecuencia cardíaca: ${this.#frecuenciaCardiaca} bpm`);
    console.log(`Nivel de hidratación: ${this.#nivelHidratacion}%`);
    console.log(`Intensidad: ${this._intensidad}`);
  }

  recomendarDescanso() {
    if (this.#frecuenciaCardiaca > 160) {
      this._descansoRecomendado = 15;
      console.log("⏸ Descanso recomendado: 15 minutos (frecuencia alta)");
    } else {
      console.log(` Descanso recomendado: ${this._descansoRecomendado} minutos`);
    }
  }
}

// --- 🔹 Ejemplo de uso ---
const sesion1 = new ControlTiempoEjercicio("Carlos López", "Ciclismo", 45, 350, false);

// Se añaden detalles JSON
sesion1.detallesJSON = {
  lugar: "Gimnasio Central",
  musica: "Pop Energético",
  fecha: "2025-11-09"
};

// Inicio de sesión
sesion1.iniciarSesion();

// Registro del ritmo
sesion1.registrarRitmo(155, 85);

// Mostrar resumen
sesion1.mostrarResumen();

// Recomendación de descanso
sesion1.recomendarDescanso();

// Finalizar sesión
sesion1.finalizarSesion();