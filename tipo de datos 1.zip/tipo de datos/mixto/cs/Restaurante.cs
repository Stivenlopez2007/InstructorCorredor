using System;
using System.Text.Json; // Para manejar datos en formato JSON

namespace Mixto
{
    public class Restaurante
    {
        // --- 🔹 5 PUBLICOS ---
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string TipoComida { get; set; }
        public bool Abierto { get; set; }
        public int NumeroMesas { get; set; }

        // --- 🔹 5 PRIVADOS ---
        private double ingresosDia;           // Ingresos totales del día
        private int pedidosCompletados;       // Número de pedidos atendidos
        private bool cocinaActiva;            // Si la cocina está en funcionamiento
        private byte[] logoRestaurante;       // Imagen del logo
        private JsonDocument menuJSON;        // Menú en formato JSON

        // --- 🔹 5 PROTECTED ---
        protected string ChefPrincipal;       // Nombre del chef
        protected int Empleados;              // Total de empleados
        protected double Calificacion;        // Promedio de reseñas
        protected bool ServicioDomicilio;     // Si ofrece entregas
        protected string ProveedorAlimentos;  // Empresa proveedora

        // --- 🔹 Constructor ---
        public Restaurante(string nombre, string direccion, string tipoComida)
        {
            Nombre = nombre;
            Direccion = direccion;
            TipoComida = tipoComida;
            Abierto = false;
            NumeroMesas = 10;

            ingresosDia = 0;
            pedidosCompletados = 0;
            cocinaActiva = false;
            logoRestaurante = Array.Empty<byte>();
            menuJSON = JsonDocument.Parse("{\"menu\": []}");

            ChefPrincipal = "Carlos Ramírez";
            Empleados = 5;
            Calificacion = 4.5;
            ServicioDomicilio = true;
            ProveedorAlimentos = "Distribuidora Gourmet S.A.";
        }

        // --- 🔹 Getters y Setters privados ---
        public double GetIngresosDia() => ingresosDia;
        public void SetIngresosDia(double valor)
        {
            if (valor >= 0)
                ingresosDia = valor;
            else
                Console.WriteLine("Los ingresos no pueden ser negativos.");
        }

        // --- 🔹 Métodos de acción ---
        public void Abrir()
        {
            Abierto = true;
            cocinaActiva = true;
            Console.WriteLine(" El restaurante ha abierto sus puertas.");
        }

        public void RegistrarPedido(string plato, double precio)
        {
            if (Abierto && cocinaActiva)
            {
                pedidosCompletados++;
                ingresosDia += precio;
                Console.WriteLine($"Pedido completado: {plato} (${precio})");
            }
            else
            {
                Console.WriteLine("No se pueden registrar pedidos, la cocina está cerrada.");
            }
        }

        public void MostrarEstado()
        {
            Console.WriteLine("\n--- Estado del Restaurante ---");
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"Dirección: {Direccion}");
            Console.WriteLine($"Tipo de comida: {TipoComida}");
            Console.WriteLine($"Chef principal: {ChefPrincipal}");
            Console.WriteLine($"Empleados: {Empleados}");
            Console.WriteLine($"Pedidos completados: {pedidosCompletados}");
            Console.WriteLine($"Ingresos del día: ${ingresosDia}");
            Console.WriteLine($"Servicio a domicilio: {(ServicioDomicilio ? "Sí" : "No")}");
            Console.WriteLine($"Proveedor: {ProveedorAlimentos}");
            Console.WriteLine($"Calificación general: {Calificacion}");
            Console.WriteLine("------------------------------\n");
        }

        public void Cerrar()
        {
            Abierto = false;
            cocinaActiva = false;
            Console.WriteLine("El restaurante ha cerrado.");
        }

        // --- 🔹 Método Main para probar ---
        public static void Main()
        {
            Restaurante r1 = new Restaurante("Sabores del Valle", "Calle 10 #23-45", "Comida Colombiana");
            r1.Abrir();
            r1.RegistrarPedido("Bandeja Paisa", 25000);
            r1.RegistrarPedido("Ajiaco", 18000);
            r1.MostrarEstado();
            r1.Cerrar();
        }
    }
}
