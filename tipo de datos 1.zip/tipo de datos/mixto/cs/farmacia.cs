using System;
using System.Text.Json; // Para manejar información JSON

namespace Mixto
{
    public class Farmacia
    {
        // --- 🔹 5 PUBLICOS ---
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Encargado { get; set; }
        public bool Abierta { get; set; }
        public int NumeroEmpleados { get; set; }

        // --- 🔹 5 PRIVADOS ---
        private double ingresosDiarios;       // Total de ventas del día
        private int ventasRealizadas;         // Número de ventas
        private bool sistemaActivo;           // Si el sistema está en línea
        private byte[] logoFarmacia;          // Logo en formato binario
        private JsonDocument registroVentas;  // Datos de ventas en JSON

        // --- 🔹 5 PROTECTED ---
        protected double PrecioPromedio;      // Precio medio de los productos
        protected int ProductosDisponibles;   // Cantidad de productos en stock
        protected bool TurnoNoche;            // Si trabaja de noche
        protected string TipoFarmacia;        // “Popular” o “Clínica”
        protected string ProveedorPrincipal;  // Nombre del proveedor

        // --- 🔹 Constructor ---
        public Farmacia(string nombre, string direccion, string encargado)
        {
            Nombre = nombre;
            Direccion = direccion;
            Encargado = encargado;
            Abierta = false;
            NumeroEmpleados = 3;

            ingresosDiarios = 0;
            ventasRealizadas = 0;
            sistemaActivo = true;
            logoFarmacia = Array.Empty<byte>();
            registroVentas = JsonDocument.Parse("{}");

            PrecioPromedio = 25000;
            ProductosDisponibles = 150;
            TurnoNoche = false;
            TipoFarmacia = "Popular";
            ProveedorPrincipal = "Distribuidora Salud Total";
        }

        // --- 🔹 Getters y Setters privados ---
        public double GetIngresos() => ingresosDiarios;
        public void SetIngresos(double valor)
        {
            if (valor >= 0)
                ingresosDiarios = valor;
            else
                Console.WriteLine("El valor no puede ser negativo.");
        }

        // --- 🔹 Métodos de acción ---
        public void Abrir()
        {
            Abierta = true;
            Console.WriteLine("La farmacia ha abierto.");
        }

        public void RegistrarVenta(string producto, double precio)
        {
            if (Abierta && ProductosDisponibles > 0)
            {
                ventasRealizadas++;
                ingresosDiarios += precio;
                ProductosDisponibles--;
                Console.WriteLine($"Venta registrada: {producto} (${precio})");
            }
            else
            {
                Console.WriteLine("No se puede registrar la venta (cerrada o sin stock).");
            }
        }

        public void MostrarEstado()
        {
            Console.WriteLine("\n--- Estado de la Farmacia ---");
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"Dirección: {Direccion}");
            Console.WriteLine($"Encargado: {Encargado}");
            Console.WriteLine($"Abierta: {(Abierta ? "Sí" : "No")}");
            Console.WriteLine($"Productos disponibles: {ProductosDisponibles}");
            Console.WriteLine($"Ventas realizadas: {ventasRealizadas}");
            Console.WriteLine($"Ingresos del día: ${ingresosDiarios}");
            Console.WriteLine($"Proveedor principal: {ProveedorPrincipal}");
            Console.WriteLine($"Tipo de farmacia: {TipoFarmacia}");
            Console.WriteLine("-----------------------------\n");
        }

        public void Cerrar()
        {
            Abierta = false;
            Console.WriteLine(" La farmacia ha cerrado.");
        }

        // --- 🔹 Método Main para probar ---
        public static void Main()
        {
            Farmacia f1 = new Farmacia("Farmacia VidaPlena", "Cra 8 #12-34", "Laura Gómez");
            f1.Abrir();
            f1.RegistrarVenta("Paracetamol", 3000);
            f1.RegistrarVenta("Ibuprofeno", 3500);
            f1.MostrarEstado();
            f1.Cerrar();
        }
    }
}
