using System;
using System.Text.Json; // Para manejar JSON

namespace Mixto
{
    public class CarroInteligente
    {
        // --- 🔹 5 PUBLICOS ---
        public string Marca { get; set; }
        public string Modelo { get; set; }
        public string Color { get; set; }
        public double VelocidadMaxima { get; set; }
        public bool Encendido { get; set; }

        // --- 🔹 5 PRIVADOS ---
        private double velocidadActual;
        private double combustible;
        private JsonDocument configuracion;
        private bool gpsActivo;
        private byte[] registroAudio;

        // --- 🔹 5 PROTECTED ---
        protected bool CinturonesAbrochados;
        protected bool LucesEncendidas;
        protected string ModoConduccion;
        protected int PuertasCerradas;
        protected double Kilometraje;

        // --- 🔹 Constructor ---
        public CarroInteligente(string marca, string modelo, string color, double velocidadMaxima)
        {
            Marca = marca;
            Modelo = modelo;
            Color = color;
            VelocidadMaxima = velocidadMaxima;
            Encendido = false;
            velocidadActual = 0;
            combustible = 100;
            gpsActivo = false;
            registroAudio = Array.Empty<byte>();
            configuracion = JsonDocument.Parse("{}");
            ModoConduccion = "Normal";
            Kilometraje = 0;
        }

        // --- 🔹 Getters y Setters privados ---
        public double GetCombustible() => combustible;

        public void SetCombustible(double valor)
        {
            if (valor < 0 || valor > 100)
                Console.WriteLine(" Nivel de combustible inválido.");
            else
                combustible = valor;
        }

        // --- 🔹 Métodos de acción ---
        public void Encender()
        {
            if (!Encendido)
            {
                Encendido = true;
                Console.WriteLine("El carro está encendido.");
            }
            else
                Console.WriteLine(" Ya estaba encendido.");
        }

        public void Acelerar(double velocidad)
        {
            if (Encendido && combustible > 0)
            {
                velocidadActual = Math.Min(velocidad, VelocidadMaxima);
                combustible -= 5;
                Kilometraje += 1.5;
                Console.WriteLine($"Acelerando a {velocidadActual} km/h.");
            }
            else
                Console.WriteLine("No se puede acelerar. Verifica encendido o combustible.");
        }

        public void Frenar()
        {
            if (velocidadActual > 0)
            {
                velocidadActual = 0;
                Console.WriteLine(" El carro se ha detenido.");
            }
            else
                Console.WriteLine(" Ya está detenido.");
        }

        public void ActivarLuces()
        {
            LucesEncendidas = !LucesEncendidas;
            Console.WriteLine($" Luces {(LucesEncendidas ? "encendidas" : "apagadas")}");
        }

        public void MostrarEstado()
        {
            Console.WriteLine("\n--- Estado del Carro ---");
            Console.WriteLine($"Marca: {Marca}");
            Console.WriteLine($"Modelo: {Modelo}");
            Console.WriteLine($"Color: {Color}");
            Console.WriteLine($"Velocidad actual: {velocidadActual} km/h");
            Console.WriteLine($"Combustible: {combustible}%");
            Console.WriteLine($"Luces: {(LucesEncendidas ? "Encendidas" : "Apagadas")}");
            Console.WriteLine($"Modo: {ModoConduccion}");
            Console.WriteLine($"Kilometraje: {Kilometraje} km");
            Console.WriteLine("-------------------------\n");
        }

        // --- 🔹 Método Main para probar ---
        public static void Main()
        {
            CarroInteligente carro1 = new CarroInteligente("Toyota", "Corolla", "Rojo", 220);

            carro1.MostrarEstado();
            carro1.Encender();
            carro1.Acelerar(80);
            carro1.ActivarLuces();
            carro1.Frenar();
            carro1.MostrarEstado();
        }
    }
}
