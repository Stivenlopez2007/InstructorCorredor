using System;
using System.Text.Json; // Para manejar datos JSON

namespace Mixto
{
    public class TiendaRopa
    {
        // --- 🔹 5 PUBLICOS ---
        public string Nombre { get; set; }
        public string Direccion { get; set; }
        public string Encargado { get; set; }
        public bool Abierta { get; set; }
        public int Empleados { get; set; }

        // --- 🔹 5 PRIVADOS ---
        private double ingresosDiarios;         // Ventas del día
        private int prendasVendidas;            // Número de prendas vendidas
        private bool sistemaActivo;             // Si el sistema de caja está operativo
        private byte[] logoTienda;              // Imagen binaria del logo
        private JsonDocument catalogoJSON;      // Catálogo de ropa en JSON

        // --- 🔹 5 PROTECTED ---
        protected string ProveedorPrincipal;    // Empresa proveedora
        protected double PrecioPromedio;        // Precio medio de las prendas
        protected int StockDisponible;          // Cantidad de prendas en inventario
        protected bool PromocionActiva;         // Si hay promociones vigentes
        protected string TipoTienda;            // Ejemplo: “Moda casual”, “Deportiva”

        // --- 🔹 Constructor ---
        public TiendaRopa(string nombre, string direccion, string encargado)
        {
            Nombre = nombre;
            Direccion = direccion;
            Encargado = encargado;
            Abierta = false;
            Empleados = 4;

            ingresosDiarios = 0;
            prendasVendidas = 0;
            sistemaActivo = true;
            logoTienda = Array.Empty<byte>();
            catalogoJSON = JsonDocument.Parse("{\"catalogo\": []}");

            ProveedorPrincipal = "Textiles Andina";
            PrecioPromedio = 85000;
            StockDisponible = 300;
            PromocionActiva = true;
            TipoTienda = "Moda Casual";
        }

        // --- 🔹 Getter y Setter privado ---
        public double GetIngresos() => ingresosDiarios;
        public void SetIngresos(double valor)
        {
            if (valor >= 0)
                ingresosDiarios = valor;
            else
                Console.WriteLine("El valor no puede ser negativo.");
        }

        // --- 🔹 Métodos de acción ---
        public void Abrir()
        {
            Abierta = true;
            Console.WriteLine("La tienda ha abierto al público.");
        }

        public void RegistrarVenta(string prenda, double precio)
        {
            if (Abierta && sistemaActivo && StockDisponible > 0)
            {
                prendasVendidas++;
                ingresosDiarios += precio;
                StockDisponible--;
                Console.WriteLine($" Venta realizada: {prenda} (${precio})");
            }
            else
            {
                Console.WriteLine(" No se puede registrar la venta (cerrada o sin stock).");
            }
        }

        public void MostrarEstado()
        {
            Console.WriteLine("\n--- Estado de la Tienda ---");
            Console.WriteLine($"Nombre: {Nombre}");
            Console.WriteLine($"Dirección: {Direccion}");
            Console.WriteLine($"Encargado: {Encargado}");
            Console.WriteLine($"Abierta: {(Abierta ? "Sí" : "No")}");
            Console.WriteLine($"Stock disponible: {StockDisponible}");
            Console.WriteLine($"Ventas realizadas: {prendasVendidas}");
            Console.WriteLine($"Ingresos del día: ${ingresosDiarios}");
            Console.WriteLine($"Promoción activa: {(PromocionActiva ? "Sí" : "No")}");
            Console.WriteLine($"Proveedor: {ProveedorPrincipal}");
            Console.WriteLine($"Tipo de tienda: {TipoTienda}");
            Console.WriteLine("---------------------------\n");
        }

        public void Cerrar()
        {
            Abierta = false;
            Console.WriteLine(" La tienda ha cerrado.");
        }

        // --- 🔹 Método Main para probar ---
        public static void Main()
        {
            TiendaRopa tienda = new TiendaRopa("UrbanStyle", "Av. Central #45-20", "María Torres");
            tienda.Abrir();
            tienda.RegistrarVenta("Camiseta Oversize", 95000);
            tienda.RegistrarVenta("Pantalón Jeans", 120000);
            tienda.MostrarEstado();
            tienda.Cerrar();
        }
    }
}
