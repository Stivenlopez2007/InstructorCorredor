package mixto;

import org.json.JSONObject; // Para usar JSON

public class MetodoPagoEnLinea {

   // --- 🔹 5 PUBLICOS ---
   public String nombreTitular;        // Nombre del usuario o cliente
   public String tipoPago;             // Ej: "Tarjeta", "PayPal", "Criptomoneda"
   public double monto;                // Valor del pago
   public boolean transaccionExitosa;  // Indica si se realizó el pago correctamente
   public int numeroTransaccion;       // Número identificador

   // --- 🔹 5 PRIVADOS ---
   private String numeroTarjeta;       // Número de tarjeta o cuenta
   private String codigoSeguridad;     // CVV o código secreto
   private boolean verificacion2FA;    // Autenticación de doble factor
   private byte[] comprobanteBinario;  // Tipo binario (recibo en bytes)
   private JSONObject detallePago;     // Detalle del pago en formato JSON

   // --- 🔹 5 PROTECTED ---
   protected String paisOrigen;        // País desde donde se realiza el pago
   protected double tasaImpuesto;      // Impuesto aplicado
   protected boolean requiereFactura;  // Si el usuario necesita factura
   protected String metodoMoneda;      // Ej: "USD", "EUR", "COP"
   protected int tiempoProcesamiento;  // Tiempo en segundos del proceso

   // --- 🔹 Constructor ---
   public MetodoPagoEnLinea(String nombreTitular, String tipoPago, double monto, int numeroTransaccion, boolean transaccionExitosa) {
      this.nombreTitular = nombreTitular;
      this.tipoPago = tipoPago;
      this.monto = monto;
      this.numeroTransaccion = numeroTransaccion;
      this.transaccionExitosa = transaccionExitosa;
      this.verificacion2FA = false;
      this.tasaImpuesto = 0.19; // 19% por defecto
      this.tiempoProcesamiento = 0;
   }

   // --- 🔹 Getters y Setters privados ---
   public boolean isVerificacion2FA() {
      return verificacion2FA;
   }

   public void setVerificacion2FA(boolean verificacion2FA) {
      this.verificacion2FA = verificacion2FA;
   }

   public JSONObject getDetallePago() {
      return detallePago;
   }

   public void setDetallePago(JSONObject detallePago) {
      this.detallePago = detallePago;
   }

   // --- 🔹 Métodos de acción ---
   public void procesarPago() {
      if (verificacion2FA && monto > 0) {
         transaccionExitosa = true;
         tiempoProcesamiento = 5;
         System.out.println("Pago procesado exitosamente por " + nombreTitular);
         System.out.println("Monto total: $" + monto);
      } else {
         transaccionExitosa = false;
         System.out.println("No se pudo procesar el pago. Verifique el monto o la autenticación.");
      }
   }

   public void generarComprobante() {
      if (transaccionExitosa) {
         System.out.println("Comprobante generado para la transacción #" + numeroTransaccion);
      } else {
         System.out.println(" No se puede generar comprobante: el pago no fue exitoso.");
      }
   }

   public void mostrarResumen() {
      System.out.println("----- Resumen del Pago en Línea -----");
      System.out.println("Titular: " + nombreTitular);
      System.out.println("Tipo de Pago: " + tipoPago);
      System.out.println("Monto: $" + monto);
      System.out.println("Transacción Exitosa: " + transaccionExitosa);
      System.out.println("Impuesto aplicado: " + (tasaImpuesto * 100) + "%");
      System.out.println("País de origen: " + paisOrigen);
   }
}

