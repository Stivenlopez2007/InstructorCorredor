package java;



public class Carro {

   // --- 5 PUBLICOS ---
   public String marca;
   public String modelo;
   public double precio;
   public int puertas;
   public boolean disponible;

   // --- 5 PRIVADOS ---
   private String color;
   private boolean encendido;
   private char tipoCombustible;
   private byte[] codigoBinario; // tipo binario
   private java.util.Map<String, Object> datosTecnicos; // tipo JSON (usando Map para evitar dependencia externa)

   // --- 5 PROTECTED ---
   protected String tipoTransmision;
   protected int anioFabricacion;
   protected double kilometraje;
   protected boolean enMantenimiento;
   protected String paisOrigen;

   // --- Constructor ---
   public Carro(String marca, String modelo, double precio, int puertas, boolean disponible) {
      this.marca = marca;
      this.modelo = modelo;
      this.precio = precio;
      this.puertas = puertas;
      this.disponible = disponible;
      this.encendido = false;
   }

   // --- Getters y Setters privados ---
   public boolean isEncendido() {
      return encendido;
   }

   public void setEncendido(boolean encendido) {
      this.encendido = encendido;
   }

   public java.util.Map<String, Object> getDatosTecnicos() {
      return datosTecnicos;
   }

   public void setDatosTecnicos(java.util.Map<String, Object> datosTecnicos) {
      this.datosTecnicos = datosTecnicos;
   }

   // --- Métodos de acción ---
   public void encender() {
      this.encendido = true;
      System.out.println("El carro está encendido.");
   }

   public void apagar() {
      this.encendido = false;
      System.out.println("El carro está apagado.");
   }
}

