package java;

import org.json.JSONObject;

/**
 * Clase que representa un motor con sus características y funcionalidades.
 */
public class Motor {
    
    // ===== ATRIBUTOS PÚBLICOS =====
    public String tipoMotor;          // Ej: "V8", "Eléctrico"
    public int cilindros;             // Ej: 4, 6, 8
    public double potenciaHP;         // Caballos de fuerza
    public boolean enFuncionamiento;  // Si el motor está encendido
    public String fabricante;         // Marca del motor
    
    // ===== ATRIBUTOS PRIVADOS =====
    private double temperatura;       // Temperatura actual del motor (°C)
    private boolean aceiteCorrecto;   // Estado del aceite
    private byte[] codigoDiagnostico; // Código binario del diagnóstico
    private JSONObject sensores;      // Datos de sensores (JSON)
    private String numeroSerie;       // Identificador único
    
    // ===== ATRIBUTOS PROTEGIDOS =====
    protected int revolucionesPorMinuto;    // RPM actuales
    protected double consumoCombustible;    // L/100km
    protected String tipoCombustible;       // Ej: "Gasolina", "Diésel"
    protected boolean necesitaMantenimiento;
    protected String paisFabricacion;
    
    // ===== CONSTRUCTOR =====
    public Motor(String tipoMotor, int cilindros, double potenciaHP, 
                 String fabricante, boolean enFuncionamiento) {
        this.tipoMotor = tipoMotor;
        this.cilindros = cilindros;
        this.potenciaHP = potenciaHP;
        this.fabricante = fabricante;
        this.enFuncionamiento = enFuncionamiento;
        this.temperatura = 25.0;
        this.aceiteCorrecto = true;
    }
    
    // ===== GETTERS Y SETTERS =====
    public double getTemperatura() {
        return temperatura;
    }
    
    public void setTemperatura(double temperatura) {
        this.temperatura = temperatura;
    }
    
    public boolean isAceiteCorrecto() {
        return aceiteCorrecto;
    }
    
    public void setAceiteCorrecto(boolean aceiteCorrecto) {
        this.aceiteCorrecto = aceiteCorrecto;
    }
    
    public JSONObject getSensores() {
        return sensores;
    }
    
    public void setSensores(JSONObject sensores) {
        this.sensores = sensores;
    }
    
    public byte[] getCodigoDiagnostico() {
        return codigoDiagnostico;
    }
    
    public void setCodigoDiagnostico(byte[] codigoDiagnostico) {
        this.codigoDiagnostico = codigoDiagnostico;
    }
    
    public String getNumeroSerie() {
        return numeroSerie;
    }
    
    public void setNumeroSerie(String numeroSerie) {
        this.numeroSerie = numeroSerie;
    }
    
    // ===== MÉTODOS DE ACCIÓN =====
    /**
     * Enciende el motor si el aceite está en buen estado.
     */
    public void encender() {
        if (aceiteCorrecto) {
            enFuncionamiento = true;
            temperatura += 10;
            System.out.println("✅ El motor se ha encendido correctamente.");
        } else {
            System.out.println("❌ No se puede encender: el nivel de aceite es incorrecto.");
        }
    }
    
    /**
     * Apaga el motor y estabiliza la temperatura.
     */
    public void apagar() {
        enFuncionamiento = false;
        temperatura = 25.0;
        System.out.println("🛑 El motor se ha apagado y la temperatura se ha estabilizado.");
    }
    
    /**
     * Muestra la información completa del motor.
     */
    public void mostrarInfo() {
        System.out.println("\n===== Información del Motor =====");
        System.out.println("Tipo de Motor: " + tipoMotor);
        System.out.println("Cilindros: " + cilindros);
        System.out.println("Potencia: " + potenciaHP + " HP");
        System.out.println("Fabricante: " + fabricante);
        System.out.println("En funcionamiento: " + (enFuncionamiento ? "Sí" : "No"));
        System.out.println("Temperatura actual: " + temperatura + " °C");
        System.out.println("Aceite en buen estado: " + (aceiteCorrecto ? "Sí" : "No"));
        System.out.println("=================================\n");
    }
}