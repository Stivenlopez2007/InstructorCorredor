package java;

import org.json.JSONObject;

public class SistemaFrenado {

    // --- 🔹 5 ATRIBUTOS PUBLICOS ---
    public String tipoFreno;             // Ej: "ABS", "Disco", "Tambor"
    public boolean frenoActivo;          // Si el sistema está en uso
    public int presionActual;            // Presión del sistema (PSI)
    public String fabricante;            // Marca del sistema de frenos
    public double distanciaDetencion;    // Distancia en metros al frenar

    // --- 🔹 5 ATRIBUTOS PRIVADOS ---
    private boolean nivelLiquidoCorrecto; // Si el líquido de frenos está en buen nivel
    private double temperaturaPastillas;  // Temperatura actual de las pastillas de freno
    private JSONObject sensores;          // Datos de sensores del sistema
    private byte[] codigoError;           // Código binario de error
    private String numeroSerie;           // Identificación única del sistema

    // --- 🔹 5 ATRIBUTOS PROTECTED ---
    protected double desgastePastillas;       // Porcentaje de desgaste
    protected boolean necesitaCambio;         // Indica si requiere mantenimiento
    protected String tipoLiquido;             // Ej: DOT3, DOT4
    protected int presionMaxima;              // Presión máxima soportada
    protected String paisFabricacion;         // Lugar de fabricación

    // --- 🔹 CONSTRUCTOR ---
    public SistemaFrenado(String tipoFreno, String fabricante, double distanciaDetencion, int presionActual, boolean frenoActivo) {
        this.tipoFreno = tipoFreno;
        this.fabricante = fabricante;
        this.distanciaDetencion = distanciaDetencion;
        this.presionActual = presionActual;
        this.frenoActivo = frenoActivo;
        this.nivelLiquidoCorrecto = true;
        this.desgastePastillas = 10.5;
        this.temperaturaPastillas = 30.0;
    }

    // --- 🔹 MÉTODOS GET Y SET (privados) ---
    public boolean isNivelLiquidoCorrecto() {
        return nivelLiquidoCorrecto;
    }

    public void setNivelLiquidoCorrecto(boolean nivelLiquidoCorrecto) {
        this.nivelLiquidoCorrecto = nivelLiquidoCorrecto;
    }

    public double getTemperaturaPastillas() {
        return temperaturaPastillas;
    }

    public void setTemperaturaPastillas(double temperaturaPastillas) {
        this.temperaturaPastillas = temperaturaPastillas;
    }

    public JSONObject getSensores() {
        return sensores;
    }

    public void setSensores(JSONObject sensores) {
        this.sensores = sensores;
    }

    // --- 🔹 MÉTODOS DE ACCIÓN ---
    public void aplicarFreno() {
        if (nivelLiquidoCorrecto && desgastePastillas < 80) {
            frenoActivo = true;
            presionActual += 10;
            distanciaDetencion -= 1.5;
            temperaturaPastillas += 20;
            System.out.println("🛑 Freno aplicado correctamente. El vehículo está desacelerando.");
        } else {
            System.out.println("⚠️ No se puede frenar: verifique el nivel de líquido o cambie las pastillas.");
        }
    }

    public void liberarFreno() {
        frenoActivo = false;
        presionActual -= 10;
        temperaturaPastillas -= 15;
        System.out.println("✅ Freno liberado. El sistema vuelve a su estado normal.");
    }

    public void mostrarEstado() {
        System.out.println("----- ESTADO DEL SISTEMA DE FRENADO -----");
        System.out.println("Tipo de freno: " + tipoFreno);
        System.out.println("Fabricante: " + fabricante);
        System.out.println("Presión actual: " + presionActual + " PSI");
        System.out.println("Temperatura de pastillas: " + temperaturaPastillas + " °C");
        System.out.println("Desgaste de pastillas: " + desgastePastillas + " %");
        System.out.println("Nivel de líquido correcto: " + nivelLiquidoCorrecto);
    }
}

