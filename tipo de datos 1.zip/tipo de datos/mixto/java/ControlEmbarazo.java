package java;

// Para manejar datos en formato JSON

public class ControlEmbarazo {

   // --- 🔹 5 PUBLICOS ---
   public String nombreMadre;         // Nombre completo de la madre
   public int edadMadre;              // Edad de la madre
   public double pesoActual;          // Peso actual en kg
   public int semanasGestacion;       // Semanas de embarazo
   public boolean riesgoAlto;         // Si tiene o no embarazo de alto riesgo

   // --- 🔹 5 PRIVADOS ---
   private String tipoSangre;         // Grupo sanguíneo
   private boolean vitaminasTomadas;  // Si tomó sus vitaminas prenatales
   private double presionArterial;    // Presión arterial actual
   private byte[] ecografiaBinaria;   // Imagen ecográfica en formato binario
   private JSONObject historialClinico; // Datos médicos en JSON

   // --- 🔹 5 PROTECTED ---
   protected String medicoEncargado;  // Nombre del médico tratante
   protected String hospitalReferencia; // Hospital o centro médico
   protected boolean seguimientoActivo; // Si tiene controles programados
   protected int controlesRealizados; // Cantidad de controles hechos
   protected double nivelHemoglobina; // Hemoglobina actual

   // --- 🔹 Constructor ---
   public ControlEmbarazo(String nombreMadre, int edadMadre, double pesoActual, int semanasGestacion, boolean riesgoAlto) {
      this.nombreMadre = nombreMadre;
      this.edadMadre = edadMadre;
      this.pesoActual = pesoActual;
      this.semanasGestacion = semanasGestacion;
      this.riesgoAlto = riesgoAlto;
      this.vitaminasTomadas = false;
      this.seguimientoActivo = true;
      this.controlesRealizados = 0;
   }

   // --- 🔹 Getters y Setters privados ---
   public boolean isVitaminasTomadas() {
      return vitaminasTomadas;
   }

   public void setVitaminasTomadas(boolean vitaminasTomadas) {
      this.vitaminasTomadas = vitaminasTomadas;
   }

   public JSONObject getHistorialClinico() {
      return historialClinico;
   }

   public void setHistorialClinico(JSONObject historialClinico) {
      this.historialClinico = historialClinico;
   }

   // --- 🔹 Métodos de acción ---
   public void registrarControl(double nuevoPeso, double presion, double hemoglobina) {
      this.pesoActual = nuevoPeso;
      this.presionArterial = presion;
      this.nivelHemoglobina = hemoglobina;
      this.controlesRealizados++;
      System.out.println(" Control registrado correctamente. Total de controles: " + controlesRealizados);
   }

   public void mostrarResumen() {
      System.out.println("----- Resumen del Control de Embarazo -----");
      System.out.println("Madre: " + nombreMadre + " (Edad: " + edadMadre + ")");
      System.out.println("Semanas de gestación: " + semanasGestacion);
      System.out.println("Peso actual: " + pesoActual + " kg");
      System.out.println("Embarazo de alto riesgo: " + (riesgoAlto ? "Sí" : "No"));
      System.out.println("Controles realizados: " + controlesRealizados);
      System.out.println("Nivel de hemoglobina: " + nivelHemoglobina);
   }

   public void evaluarRiesgo() {
      if (presionArterial > 140 || nivelHemoglobina < 11) {
         riesgoAlto = true;
         System.out.println(" Riesgo alto detectado. Se requiere control médico urgente.");
      } else {
         riesgoAlto = false;
         System.out.println("Estado estable. Continuar controles normales.");
      }
   }
}
