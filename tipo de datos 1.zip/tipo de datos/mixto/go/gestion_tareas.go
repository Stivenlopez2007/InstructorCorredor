package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// ----------------------------------------------------
// ESTRUCTURA PRINCIPAL
// ----------------------------------------------------
type GestionTareas struct {
	// --- PÚBLICOS ---
	Usuario        string
	Proyecto       string
	NumeroTareas   int
	Completadas    int
	Activo         bool

	// --- PRIVADOS ---
	listaTareas       []string
	estadoTareas      map[string]bool
	ultimaActualizacion time.Time
	configuracion      map[string]interface{}
	nivelProductividad float64

	// --- “PROTEGIDOS” (por convención con prefijo _) ---
	_FechaInicio     time.Time
	_TareasPendientes int
	_PromedioDiario   float64
	_Eficiencia       float64
	_UltimaTarea      string
}

// ----------------------------------------------------
// CONSTRUCTOR
// ----------------------------------------------------
func NuevaGestion(usuario, proyecto string) *GestionTareas {
	return &GestionTareas{
		Usuario:        usuario,
		Proyecto:       proyecto,
		NumeroTareas:   0,
		Completadas:    0,
		Activo:         true,
		listaTareas:    []string{},
		estadoTareas:   make(map[string]bool),
		configuracion:  make(map[string]interface{}),
		_FechaInicio:   time.Now(),
	}
}

// ----------------------------------------------------
// MÉTODOS DE ACCIÓN
// ----------------------------------------------------

// AgregarTarea añade una nueva tarea a la lista
func (g *GestionTareas) AgregarTarea(nombre string) {
	if !g.Activo {
		fmt.Println("La gestión de tareas está inactiva.")
		return
	}
	g.listaTareas = append(g.listaTareas, nombre)
	g.estadoTareas[nombre] = false
	g.NumeroTareas++
	g._TareasPendientes++
	g._UltimaTarea = nombre
	g.ultimaActualizacion = time.Now()
	fmt.Printf("Tarea agregada: '%s'\n", nombre)
}

// CompletarTarea marca una tarea como completada
func (g *GestionTareas) CompletarTarea(nombre string) {
	if _, existe := g.estadoTareas[nombre]; !existe {
		fmt.Printf("La tarea '%s' no existe.\n", nombre)
		return
	}
	if g.estadoTareas[nombre] {
		fmt.Printf("La tarea '%s' ya estaba completada.\n", nombre)
		return
	}
	g.estadoTareas[nombre] = true
	g.Completadas++
	g._TareasPendientes--
	g.ultimaActualizacion = time.Now()
	fmt.Printf("Tarea completada: '%s'\n", nombre)
	g.CalcularEficiencia()
}

// CalcularEficiencia evalúa el rendimiento según tareas completadas
func (g *GestionTareas) CalcularEficiencia() {
	if g.NumeroTareas == 0 {
		g._Eficiencia = 0
		return
	}
	g._Eficiencia = (float64(g.Completadas) / float64(g.NumeroTareas)) * 100
	if g._Eficiencia > 80 {
		g.nivelProductividad = 5
	} else if g._Eficiencia >= 50 {
		g.nivelProductividad = 3.5
	} else {
		g.nivelProductividad = 2
	}
}

// MostrarResumen imprime el estado general del proyecto
func (g *GestionTareas) MostrarResumen() {
	fmt.Println("\n--- RESUMEN DE GESTIÓN DE TAREAS ---")
	fmt.Printf("Usuario: %s\nProyecto: %s\n", g.Usuario, g.Proyecto)
	fmt.Printf("Tareas: %d | Completadas: %d | Pendientes: %d\n",
		g.NumeroTareas, g.Completadas, g._TareasPendientes)
	fmt.Printf("Eficiencia: %.1f%% | Productividad: %.1f/5\n", g._Eficiencia, g.nivelProductividad)
	fmt.Printf("Última tarea registrada: %s\nÚltima actualización: %s\n",
		g._UltimaTarea, g.ultimaActualizacion.Format("2006-01-02 15:04"))
}

// ----------------------------------------------------
// MÉTODOS AUXILIARES
// ----------------------------------------------------
func (g *GestionTareas) SetConfiguracion(cfg map[string]interface{}) {
	g.configuracion = cfg
}

func (g *GestionTareas) MostrarConfiguracion() {
	if len(g.configuracion) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(g.configuracion, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// ----------------------------------------------------
// MAIN
// ----------------------------------------------------
func main() {
	// Crear nueva gestión
	gestion := NuevaGestion("Andrea", "Desarrollo Backend")

	// Configurar parámetros iniciales
	cfg := map[string]interface{}{
		"notificaciones":  true,
		"recordatorios":   "08:00 AM y 18:00 PM",
		"modo_productivo": "estricto",
	}
	gestion.SetConfiguracion(cfg)

	// Registrar tareas
	gestion.AgregarTarea("Diseñar base de datos")
	gestion.AgregarTarea("Implementar API")
	gestion.AgregarTarea("Probar endpoints")
	gestion.AgregarTarea("Documentar API")

	// Completar algunas tareas
	gestion.CompletarTarea("Diseñar base de datos")
	gestion.CompletarTarea("Implementar API")

	// Mostrar estado actual
	gestion.MostrarResumen()
	gestion.MostrarConfiguracion()
}
