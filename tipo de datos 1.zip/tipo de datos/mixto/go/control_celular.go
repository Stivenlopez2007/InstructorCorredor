package main

import (
	"encoding/json"
	"fmt"
	"time"
)

//
// ESTRUCTURA PRINCIPAL

type ControlCelular struct {
	// Públicos (Mayúscula inicial = Exportados) 
	Marca            string
	Modelo           string
	SistemaOperativo string
	Almacenamiento   int
	Encendido        bool

	// Privados (minúscula inicial = no exportados) 
	nivelBateria     int
	conectadoWifi    bool
	codigoDesbloqueo string
	registroBinario  []byte
	configuracion    map[string]interface{}

	//  “Protegidos” (solo convención con _ prefijo) 
	_VersionSoftware   string
	_FechaUltimaCarga  time.Time
	_ModoOscuro        bool
	_Temperatura       float64
	_ListaAplicaciones []string
}


// CONSTRUCTOR
func NuevoControlCelular(marca, modelo, so string, almacenamiento int) *ControlCelular {
	return &ControlCelular{
		Marca:              marca,
		Modelo:             modelo,
		SistemaOperativo:   so,
		Almacenamiento:     almacenamiento,
		nivelBateria:       100,
		conectadoWifi:      false,
		codigoDesbloqueo:   "0000",
		_VersionSoftware:   "1.0.0",
		_ModoOscuro:        false,
		_Temperatura:       28.5,
		_ListaAplicaciones: []string{"Teléfono", "Mensajes", "Cámara"},
	}
}

// MÉTODOS DE ACCIÓN

// EncenderCelular activa el dispositivo
func (c *ControlCelular) EncenderCelular() {
	if c.Encendido {
		fmt.Println(" El celular ya está encendido.")
		return
	}
	c.Encendido = true
	fmt.Printf("📱 %s %s encendido correctamente.\n", c.Marca, c.Modelo)
}

// ApagarCelular apaga el dispositivo
func (c *ControlCelular) ApagarCelular() {
	if !c.Encendido {
		fmt.Println("El celular ya está apagado.")
		return
	}
	c.Encendido = false
	fmt.Println(" El celular se ha apagado.")
}

// CargarBateria recarga la batería al 100%
func (c *ControlCelular) CargarBateria() {
	c.nivelBateria = 100
	c._FechaUltimaCarga = time.Now()
	fmt.Printf(" Batería cargada al 100%% (%s)\n",
		c._FechaUltimaCarga.Format("02-01-2006 15:04:05"))
}

// ConectarWifi simula la conexión a una red Wi-Fi
func (c *ControlCelular) ConectarWifi(red string) {
	c.conectadoWifi = true
	fmt.Printf("Conectado a la red Wi-Fi \"%s\".\n", red)
}

// AbrirAplicacion permite abrir una app instalada
func (c *ControlCelular) AbrirAplicacion(nombre string) {
	if !c.Encendido {
		fmt.Println(" No se puede abrir aplicaciones con el celular apagado.")
		return
	}

	for _, app := range c._ListaAplicaciones {
		if app == nombre {
			fmt.Printf("📲 Abriendo la aplicación: %s...\n", nombre)
			c.nivelBateria -= 2
			return
		}
	}
	fmt.Printf(" La aplicación \"%s\" no está instalada.\n", nombre)
}
//  MÉTODOS AUXILIARES


// MostrarEstado imprime un resumen del estado actual
func (c *ControlCelular) MostrarEstado() {
	fmt.Println("\n--- ESTADO DEL CELULAR ---")
	fmt.Printf("Marca: %s\nModelo: %s\nSO: %s\nVersión: %s\n",
		c.Marca, c.Modelo, c.SistemaOperativo, c._VersionSoftware)
	fmt.Printf("Encendido: %t | Batería: %d%% | Wi-Fi: %t\n",
		c.Encendido, c.nivelBateria, c.conectadoWifi)
	fmt.Printf("Modo oscuro: %t | Temperatura: %.1f°C\n",
		c._ModoOscuro, c._Temperatura)
}

// MostrarConfiguracion muestra los datos JSON de configuración
func (c *ControlCelular) MostrarConfiguracion() {
	if c.configuracion == nil {
		fmt.Println("⚠️ No hay configuración disponible.")
		return
	}

	data, _ := json.MarshalIndent(c.configuracion, "", "  ")
	fmt.Println(" Configuración actual:")
	fmt.Println(string(data))
}

//  SETTERS Y GETTERS
func (c *ControlCelular) SetConfiguracion(config map[string]interface{}) {
	c.configuracion = config
}

func (c *ControlCelular) GetConfiguracion() map[string]interface{} {
	return c.configuracion
}


// FUNCIÓN PRINCIPAL (MAIN)

func main() {
	// Creación del objeto
	cel := NuevoControlCelular("Samsung", "Galaxy S24", "Android", 256)

	// Configuración inicial (map -> JSON)
	config := map[string]interface{}{
		"idioma": "Español",
		"region": "Latinoamérica",
		"brillo": 75,
		"sonido": true,
	}
	cel.SetConfiguracion(config)

	// Flujo de acciones
	cel.EncenderCelular()
	cel.ConectarWifi("Red_Hogar")
	cel.AbrirAplicacion("Cámara")
	cel.MostrarEstado()
	cel.MostrarConfiguracion()
	cel.CargarBateria()
	cel.ApagarCelular()
}
