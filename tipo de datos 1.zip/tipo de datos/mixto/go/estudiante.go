package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// ----------------------------------------------------
// ESTRUCTURA PRINCIPAL
// ----------------------------------------------------
type AprendiendoGo struct {
	// --- Públicos ---
	NombreEstudiante string
	NivelActual      string
	HorasEstudio     int
	AvancePorcentaje float64
	Activo           bool

	// --- Privados ---
	progresoSemanal  []int
	temasCompletados []string
	calificacion     float64
	feedbackProfesor string
	configuracion    map[string]interface{}

	// --- “Protegidos” (convención con prefijo _) ---
	_FechaInicio  time.Time
	_DiasTotales  int
	_Certificado  bool
	_UltimoTema   string
	_LenguajeBase string
}

// ----------------------------------------------------
// CONSTRUCTOR
// ----------------------------------------------------
func NuevoAprendiz(nombre string) *AprendiendoGo {
	return &AprendiendoGo{
		NombreEstudiante: nombre,
		NivelActual:      "Básico",
		HorasEstudio:     0,
		AvancePorcentaje: 0,
		Activo:           true,
		_FechaInicio:     time.Now(),
		_DiasTotales:     0,
		_Certificado:     false,
		_LenguajeBase:    "Go",
		configuracion:    make(map[string]interface{}),
	}
}

// ----------------------------------------------------
// MÉTODOS DE ACCIÓN
// ----------------------------------------------------

// Estudiar suma horas y aumenta el progreso
func (a *AprendiendoGo) Estudiar(horas int) {
	if !a.Activo {
		fmt.Println("El estudiante no está activo.")
		return
	}
	a.HorasEstudio += horas
	a.AvancePorcentaje += float64(horas) * 2.5
	if a.AvancePorcentaje > 100 {
		a.AvancePorcentaje = 100
	}
	a._DiasTotales++
	fmt.Printf("%s estudió %d horas. Progreso: %.1f%%\n",
		a.NombreEstudiante, horas, a.AvancePorcentaje)
}

// CompletarTema agrega un tema aprendido
func (a *AprendiendoGo) CompletarTema(tema string) {
	a.temasCompletados = append(a.temasCompletados, tema)
	a._UltimoTema = tema
	fmt.Printf("Tema completado: %s\n", tema)
}

// Evaluar simula una evaluación con calificación
func (a *AprendiendoGo) Evaluar(puntaje float64) {
	a.calificacion = puntaje
	if puntaje >= 3.5 {
		a.feedbackProfesor = "Buen desempeño, sigue así."
	} else {
		a.feedbackProfesor = "Necesitas reforzar conceptos básicos."
	}
	fmt.Printf("Evaluación completada. Nota: %.1f | Feedback: %s\n",
		puntaje, a.feedbackProfesor)
}

// Certificar revisa si el estudiante alcanzó el 100% del progreso
func (a *AprendiendoGo) Certificar() {
	if a.AvancePorcentaje >= 100 {
		a._Certificado = true
		fmt.Printf("Felicidades %s, has completado el curso de Go.\n", a.NombreEstudiante)
	} else {
		fmt.Println("Aún no has alcanzado el 100% de progreso.")
	}
}

// MostrarEstado muestra el resumen del progreso actual
func (a *AprendiendoGo) MostrarEstado() {
	fmt.Println("\n--- ESTADO DE APRENDIZAJE ---")
	fmt.Printf("Estudiante: %s\nNivel: %s\nProgreso: %.1f%%\nHoras: %d\n",
		a.NombreEstudiante, a.NivelActual, a.AvancePorcentaje, a.HorasEstudio)
	fmt.Printf("Último tema: %s\nCertificado: %t\n",
		a._UltimoTema, a._Certificado)
}

// ----------------------------------------------------
// MÉTODOS AUXILIARES
// ----------------------------------------------------
func (a *AprendiendoGo) SetConfiguracion(config map[string]interface{}) {
	a.configuracion = config
}

func (a *AprendiendoGo) MostrarConfiguracion() {
	if len(a.configuracion) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(a.configuracion, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// ----------------------------------------------------
// MAIN
// ----------------------------------------------------
func main() {
	// Crear estudiante
	est := NuevoAprendiz("Laura")

	// Configuración inicial
	config := map[string]interface{}{
		"modo":       "autodidacta",
		"idioma":     "español",
		"duracion_d": 30,
	}
	est.SetConfiguracion(config)

	// Simular progreso
	est.Estudiar(4)
	est.CompletarTema("Sintaxis básica")
	est.Evaluar(4.0)
	est.Estudiar(6)
	est.CompletarTema("Estructuras y métodos")
	est.Certifica
