package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// ----------------------------------------------------
// ESTRUCTURA PRINCIPAL
// ----------------------------------------------------
type ControlHabitos struct {
	// --- PÚBLICOS ---
	NombreUsuario  string
	HabitoPrincipal string
	DiasObjetivo    int
	ProgresoTotal   float64
	Activo          bool

	// --- PRIVADOS ---
	historialCumplimiento []bool
	fechaUltimoRegistro   time.Time
	comentarioMotivacion  string
	configuracionUsuario  map[string]interface{}
	nivelSatisfaccion     float64

	// --- “PROTEGIDOS” (convención con prefijo _) ---
	_DiasCumplidos int
	_FechaInicio   time.Time
	_Promedio      float64
	_EsConstante   bool
	_TipoHabito    string
}

// ----------------------------------------------------
// CONSTRUCTOR
// ----------------------------------------------------
func NuevoControl(nombre string, habito string, dias int) *ControlHabitos {
	return &ControlHabitos{
		NombreUsuario:  nombre,
		HabitoPrincipal: habito,
		DiasObjetivo:    dias,
		ProgresoTotal:   0,
		Activo:          true,
		_FechaInicio:    time.Now(),
		historialCumplimiento: []bool{},
		configuracionUsuario:  make(map[string]interface{}),
	}
}

// ----------------------------------------------------
// MÉTODOS DE ACCIÓN
// ----------------------------------------------------

// RegistrarDia marca un día como cumplido o no cumplido
func (c *ControlHabitos) RegistrarDia(cumplido bool) {
	if !c.Activo {
		fmt.Println("El control de hábitos está inactivo.")
		return
	}
	c.historialCumplimiento = append(c.historialCumplimiento, cumplido)
	c.fechaUltimoRegistro = time.Now()
	if cumplido {
		c._DiasCumplidos++
	}
	c.CalcularProgreso()
}

// CalcularProgreso actualiza el porcentaje de cumplimiento
func (c *ControlHabitos) CalcularProgreso() {
	if c.DiasObjetivo == 0 {
		c.ProgresoTotal = 0
		return
	}
	c.ProgresoTotal = (float64(c._DiasCumplidos) / float64(c.DiasObjetivo)) * 100
	c._Promedio = c.ProgresoTotal / float64(len(c.historialCumplimiento))
	c._EsConstante = c._Promedio >= 70
}

// AgregarComentario permite agregar una nota de motivación
func (c *ControlHabitos) AgregarComentario(texto string) {
	c.comentarioMotivacion = texto
	fmt.Println("Comentario agregado:", texto)
}

// EvaluarNivel genera una nota de satisfacción
func (c *ControlHabitos) EvaluarNivel() {
	if c.ProgresoTotal >= 80 {
		c.nivelSatisfaccion = 5
	} else if c.ProgresoTotal >= 50 {
		c.nivelSatisfaccion = 3.5
	} else {
		c.nivelSatisfaccion = 2
	}
	fmt.Printf("Nivel de satisfacción: %.1f / 5\n", c.nivelSatisfaccion)
}

// MostrarResumen muestra todo el progreso actual
func (c *ControlHabitos) MostrarResumen() {
	fmt.Println("\n--- RESUMEN DE HÁBITOS ---")
	fmt.Printf("Usuario: %s\nHábito: %s\nProgreso: %.1f%%\nDías cumplidos: %d/%d\nConstante: %t\n",
		c.NombreUsuario, c.HabitoPrincipal, c.ProgresoTotal, c._DiasCumplidos, c.DiasObjetivo, c._EsConstante)
	fmt.Printf("Último registro: %s\nComentario: %s\n",
		c.fechaUltimoRegistro.Format("2006-01-02"), c.comentarioMotivacion)
}

// ----------------------------------------------------
// MÉTODOS AUXILIARES
// ----------------------------------------------------
func (c *ControlHabitos) SetConfiguracion(cfg map[string]interface{}) {
	c.configuracionUsuario = cfg
}

func (c *ControlHabitos) MostrarConfiguracion() {
	if len(c.configuracionUsuario) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(c.configuracionUsuario, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// ----------------------------------------------------
// MAIN
// ----------------------------------------------------
func main() {
	// Crear nuevo control de hábito
	control := NuevoControl("Daniel", "Ejercicio diario", 10)

	// Asignar configuración personalizada
	cfg := map[string]interface{}{
		"hora_preferida": "06:30 AM",
		"notificaciones": true,
		"modo":           "motivación alta",
	}
	control.SetConfiguracion(cfg)

	// Simular varios días
	control.RegistrarDia(true)
	control.RegistrarDia(true)
	control.RegistrarDia(false)
	control.RegistrarDia(true)
	control.RegistrarDia(true)

	control.AgregarComentario("Voy mejorando cada día.")
	control.EvaluarNivel()
	control.MostrarResumen()
	control.MostrarConfiguracion()
}
