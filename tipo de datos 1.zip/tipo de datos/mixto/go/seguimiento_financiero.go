package main

import (
	"encoding/json"
	"fmt"
	"time"
)

// ----------------------------------------------------
// ESTRUCTURA PRINCIPAL
// ----------------------------------------------------
type SeguimientoFinanciero struct {
	// --- PÚBLICOS ---
	NombreUsuario string
	Moneda        string
	SaldoActual   float64
	IngresosTotales float64
	Activo        bool

	// --- PRIVADOS ---
	gastosRegistrados   []float64
	ingresosRegistrados []float64
	categoriasGasto     map[string]float64
	ultimoMovimiento    time.Time
	configuracion       map[string]interface{}

	// --- “PROTEGIDOS” (por convención con prefijo _) ---
	_FechaInicio    time.Time
	_TotalGastos    float64
	_AhorroMensual  float64
	_LimiteGasto    float64
	_PromedioGasto  float64
}

// ----------------------------------------------------
// CONSTRUCTOR
// ----------------------------------------------------
func NuevoSeguimiento(nombre, moneda string, saldoInicial float64) *SeguimientoFinanciero {
	return &SeguimientoFinanciero{
		NombreUsuario:       nombre,
		Moneda:              moneda,
		SaldoActual:         saldoInicial,
		IngresosTotales:     0,
		Activo:              true,
		_FechaInicio:        time.Now(),
		categoriasGasto:     make(map[string]float64),
		configuracion:       make(map[string]interface{}),
	}
}

// ----------------------------------------------------
// MÉTODOS DE ACCIÓN
// ----------------------------------------------------

// RegistrarIngreso suma ingresos al saldo
func (s *SeguimientoFinanciero) RegistrarIngreso(monto float64, categoria string) {
	if !s.Activo {
		fmt.Println("El seguimiento financiero está inactivo.")
		return
	}
	s.ingresosRegistrados = append(s.ingresosRegistrados, monto)
	s.SaldoActual += monto
	s.IngresosTotales += monto
	s.ultimoMovimiento = time.Now()
	fmt.Printf("Ingreso de %.2f %s registrado en '%s'.\n", monto, s.Moneda, categoria)
}

// RegistrarGasto descuenta gastos del saldo
func (s *SeguimientoFinanciero) RegistrarGasto(monto float64, categoria string) {
	if !s.Activo {
		fmt.Println("El seguimiento financiero está inactivo.")
		return
	}
	s.gastosRegistrados = append(s.gastosRegistrados, monto)
	s.SaldoActual -= monto
	s._TotalGastos += monto
	s.categoriasGasto[categoria] += monto
	s.ultimoMovimiento = time.Now()
	s.CalcularPromedioGasto()
	fmt.Printf("Gasto de %.2f %s registrado en '%s'.\n", monto, s.Moneda, categoria)
}

// CalcularPromedioGasto calcula el promedio de gasto por registro
func (s *SeguimientoFinanciero) CalcularPromedioGasto() {
	total := 0.0
	for _, g := range s.gastosRegistrados {
		total += g
	}
	if len(s.gastosRegistrados) > 0 {
		s._PromedioGasto = total / float64(len(s.gastosRegistrados))
	}
}

// EstablecerLimite define un límite de gasto mensual
func (s *SeguimientoFinanciero) EstablecerLimite(limite float64) {
	s._LimiteGasto = limite
	fmt.Printf("Límite de gasto mensual establecido: %.2f %s\n", limite, s.Moneda)
}

// CalcularAhorroMensual estima el ahorro disponible
func (s *SeguimientoFinanciero) CalcularAhorroMensual() {
	s._AhorroMensual = s.IngresosTotales - s._TotalGastos
	fmt.Printf("Ahorro mensual estimado: %.2f %s\n", s._AhorroMensual, s.Moneda)
}

// MostrarResumen imprime un resumen financiero general
func (s *SeguimientoFinanciero) MostrarResumen() {
	fmt.Println("\n--- RESUMEN FINANCIERO ---")
	fmt.Printf("Usuario: %s\nMoneda: %s\nSaldo actual: %.2f\n", s.NombreUsuario, s.Moneda, s.SaldoActual)
	fmt.Printf("Ingresos totales: %.2f | Gastos totales: %.2f\n", s.IngresosTotales, s._TotalGastos)
	fmt.Printf("Ahorro mensual: %.2f | Promedio gasto: %.2f\n", s._AhorroMensual, s._PromedioGasto)
	fmt.Printf("Límite de gasto: %.2f | Último movimiento: %s\n",
		s._LimiteGasto, s.ultimoMovimiento.Format("2006-01-02"))
}

// ----------------------------------------------------
// MÉTODOS AUXILIARES
// ----------------------------------------------------
func (s *SeguimientoFinanciero) SetConfiguracion(cfg map[string]interface{}) {
	s.configuracion = cfg
}

func (s *SeguimientoFinanciero) MostrarConfiguracion() {
	if len(s.configuracion) == 0 {
		fmt.Println("Sin configuraciones adicionales.")
		return
	}
	data, _ := json.MarshalIndent(s.configuracion, "", "  ")
	fmt.Println("Configuración actual:")
	fmt.Println(string(data))
}

// ----------------------------------------------------
// MAIN
// ----------------------------------------------------
func main() {
	// Crear seguimiento financiero
	seguimiento := NuevoSeguimiento("Camila", "USD", 500.00)

	// Configuración inicial
	cfg := map[string]interface{}{
		"notificaciones":  true,
		"modo_ahorro":     "automático",
		"limite_alerta":   100.00,
		"resumen_semanal": true,
	}
	seguimiento.SetConfiguracion(cfg)

	// Registrar movimientos
	seguimiento.RegistrarIngreso(200.00, "Salario")
	seguimiento.RegistrarIngreso(50.00, "Regalo")
	seguimiento.RegistrarGasto(80.00, "Comida")
	seguimiento.RegistrarGasto(30.00, "Transporte")
	seguimiento.RegistrarGasto(40.00, "Entretenimiento")

	// Definir límites y cálculos
	seguimiento.EstablecerLimite(300.00)
	seguimiento.CalcularAhorroMensual()

	// Mostrar resultados
	seguimiento.MostrarResumen()
	seguimiento.MostrarConfiguracion()
}
